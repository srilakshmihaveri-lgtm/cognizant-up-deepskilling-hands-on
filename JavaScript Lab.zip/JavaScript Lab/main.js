// ==========================================
// Exercise 3: Conditionals, Loops & Error Handling
// ==========================================

console.log("===== Exercise 3 =====");

const events = [
    { name: "Sports Day", seats: 20, upcoming: true, category: "Sports" },
    { name: "Music Festival", seats: 0, upcoming: true, category: "Music" },
    { name: "Food Carnival", seats: 40, upcoming: true, category: "Food" },
    { name: "Old Event", seats: 15, upcoming: false, category: "General" }
];

// Display valid events
events.forEach(function(event){

    if(event.upcoming && event.seats>0){

        console.log(event.name + " is Available");

    }
    else{

        console.log(event.name + " is Hidden");

    }

});

// Registration with Error Handling

try{

    let seats = events[0].seats;

    if(seats<=0){

        throw "No Seats Available";

    }

    console.log("Registration Successful");

}

catch(error){

    console.log(error);

}


// ==========================================
// Exercise 4: Functions, Scope, Closures
// ==========================================

console.log("===== Exercise 4 =====");

function addEvent(name,category){

    events.push({
        name:name,
        category:category,
        seats:50,
        upcoming:true
    });

    console.log(name+" Added");

}

function registerUser(username){

    console.log(username+" Registered");

}

function filterEventsByCategory(category,callback){

    const result=events.filter(e=>e.category==category);

    callback(result);

}

function registrationCounter(){

    let total=0;

    return function(){

        total++;

        return total;

    }

}

const counter=registrationCounter();

console.log(counter());

console.log(counter());

addEvent("Coding Workshop","Education");

registerUser("Rahul");

filterEventsByCategory("Music",function(result){

    console.log(result);

});


// ==========================================
// Exercise 5: Objects & Prototypes
// ==========================================

console.log("===== Exercise 5 =====");

function Event(name,seats){

    this.name=name;
    this.seats=seats;

}

Event.prototype.checkAvailability=function(){

    if(this.seats>0)

        console.log(this.name+" Seats Available");

    else

        console.log(this.name+" Full");

}

let e1=new Event("Hackathon",50);

e1.checkAvailability();

console.log(Object.entries(e1));


// ==========================================
// Exercise 6: Arrays & Methods
// ==========================================

console.log("===== Exercise 6 =====");

let eventArray=[];

eventArray.push("Music Festival");
eventArray.push("Food Carnival");
eventArray.push("Music Workshop");

console.log(eventArray);

let musicEvents=eventArray.filter(event=>event.includes("Music"));

console.log(musicEvents);

let displayCards=eventArray.map(event=>"Workshop on "+event);

console.log(displayCards);


// ==========================================
// Exercise 7: DOM Manipulation
// ==========================================

document.addEventListener("DOMContentLoaded", function(){

    let container=document.getElementById("eventContainer");

    if(container){

        events.forEach(function(event){

            if(event.upcoming && event.seats>0){

                let card=document.createElement("div");

                card.className="card";

                card.innerHTML=`
                <h2>${event.name}</h2>
                <p>Seats : ${event.seats}</p>
                `;

                container.appendChild(card);

            }

        });

    }

    // Exercise 10 Output

    const eventDetails={
        name:"Music Festival",
        date:"25 July 2026",
        seats:100
    };

    const {name,date,seats}=eventDetails;

    function greet(user="Guest"){

        return "Welcome "+user;

    }

    const eventsList=["Sports","Music","Food"];

    const copiedEvents=[...eventsList];

    let exercise10=document.getElementById("exercise10");

    if(exercise10){

        exercise10.innerHTML=`

        <h3>${name}</h3>

        <p>Date : ${date}</p>

        <p>Seats : ${seats}</p>

        <p>${greet()}</p>

        <p>Copied Events : ${copiedEvents.join(", ")}</p>

        `;

    }

});


// ==========================================
// Exercise 8: Event Handling
// ==========================================

console.log("===== Exercise 8 =====");

function register(){

    alert("Registered Successfully");

}

function filterCategory(){

    console.log("Category Changed");

}

document.addEventListener("keydown",function(event){

    console.log("Key Pressed : "+event.key);

});


// ==========================================
// Exercise 9: Async JS, Promises & Async/Await
// ==========================================

console.log("===== Exercise 9 =====");

function fetchEvents(){

    document.getElementById("loading").innerHTML="Loading Events...";

    fetch("https://jsonplaceholder.typicode.com/users")

    .then(response=>response.json())

    .then(data=>{

        document.getElementById("loading").innerHTML="Events Loaded Successfully";

        console.log(data);

    })

    .catch(error=>{

        console.log(error);

    });

}

async function fetchEventsAsync(){

    document.getElementById("loading").innerHTML="Loading Events...";

    try{

        let response=await fetch("https://jsonplaceholder.typicode.com/users");

        let data=await response.json();

        document.getElementById("loading").innerHTML="Events Loaded Using Async/Await";

        console.log(data);

    }

    catch(error){

        console.log(error);

    }

}


// ==========================================
// Exercise 10: Modern JavaScript Features
// ==========================================

console.log("===== Exercise 10 =====");


// ==========================================
// Exercise 11: Working with Forms
// ==========================================

console.log("===== Exercise 11 =====");

function submitForm(e){

    e.preventDefault();

    let form=document.getElementById("registerForm");

    let name=form.elements["name"].value;

    let email=form.elements["email"].value;

    let selectedEvent=form.elements["event"].value;

    if(name=="" || email==""){

        document.getElementById("error").innerHTML="Please fill all fields.";

        return;

    }

    document.getElementById("error").innerHTML="";

    alert("Registration Successful");

    console.log(name,email,selectedEvent);

}


// ==========================================
// Exercise 12: AJAX & Fetch API
// ==========================================

console.log("===== Exercise 12 =====");

function sendRegistration(){

    let user={

        name:"Rahul",

        email:"rahul@gmail.com"

    };

    document.getElementById("status").innerHTML="Sending...";

    setTimeout(()=>{

        fetch("https://jsonplaceholder.typicode.com/posts",{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify(user)

        })

        .then(response=>response.json())

        .then(data=>{

            document.getElementById("status").innerHTML="Registration Sent Successfully";

            console.log(data);

        });

    },2000);

}


// ==========================================
// Exercise 13: Debugging
// ==========================================

console.log("===== Exercise 13 =====");

function debugDemo(){

    console.log("Debug Started");

    let number=10;

    console.log(number);

    console.log("Check Console and Network Tab");

}


// ==========================================
// Exercise 14: jQuery
// ==========================================

console.log("===== Exercise 14 =====");

$(document).ready(function(){

    $("#registerBtn").click(function(){

        $("#eventCard").fadeOut(1000).fadeIn(1000);

    });

});

console.log("Framework Benefit: React/Vue provide reusable components and faster UI updates.");